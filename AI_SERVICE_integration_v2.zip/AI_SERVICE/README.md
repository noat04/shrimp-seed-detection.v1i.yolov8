# AI_SERVICE: đếm tôm giống bằng YOLOv8

Dịch vụ suy luận tách ra từ dự án huấn luyện `shrimp-seed-detection`. Nhận một ảnh tôm giống, trả số con đếm được, các khung và đường dẫn ảnh gốc cùng ảnh đã vẽ khung (lưu trên Cloudinary).

**Đọc trước khi tích hợp:** [docs/INTEGRATION_SPEC.md](docs/INTEGRATION_SPEC.md) (hợp đồng API, ánh xạ giao diện, triển khai, nghiệm thu, giới hạn).

## Nội dung

- `app/`: dịch vụ FastAPI và cấu hình Cloudinary.
- `models/`: `best.pt` (YOLOv8n, mặc định) và `candidates/shrimp_domains_v3.pt` (YOLOv8s, ứng viên). Xem `models/README.md`.
- `examples/`: ví dụ gọi API (Python, Node.js, PowerShell) và phản hồi mẫu.
- `docs/INTEGRATION_SPEC.md`: tài liệu tích hợp chi tiết.
- `Dockerfile`, `docker-compose.example.yml`, `.env.example`, `requirements.txt`.

## Chạy nhanh (PowerShell)

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env          # điền 3 biến CLOUDINARY_*
uvicorn app.main:app --host 0.0.0.0 --port 8001
```

Mở `http://localhost:8001/docs` để thử `POST /predict`, hoặc `http://localhost:8001/health` để xem trạng thái. (Không mở `http://0.0.0.0:8001`: đó chỉ là địa chỉ để server lắng nghe.)

## API tóm tắt

- `POST /predict`: field `file` (bắt buộc) và các tham số query `conf` (0,25), `imgsz` (640), `max_det` (300), `tile_size` (0), `tile_overlap` (0,2), `merge_iou` (0,5). Trả `count`, `detections`, `image_url`, `annotated_image_url`...
- `GET /health`: trạng thái dịch vụ, model, Cloudinary.

**Lưu ý quan trọng:** `max_det` mặc định là 300; ảnh có nhiều hơn 300 con bị cắt âm thầm. Khuyến nghị luôn truyền `max_det=1000`.

## Docker

```powershell
docker build -t shrimp-ai-service .
```

`Dockerfile` chưa được build thử khi chuẩn bị gói; xem `docs/INTEGRATION_SPEC.md` mục 12. Truyền `CLOUDINARY_*` bằng biến môi trường hoặc secret, **không** đưa khóa thật vào image hay Git. Trong Docker Compose, backend gọi `http://ai-service:8001` (tên service, không phải `localhost`); frontend gọi backend, không gọi thẳng dịch vụ AI.

## Chuyển model

Đặt `MODEL_PATH=models/candidates/shrimp_domains_v3.pt` (hoặc `/app/models/candidates/shrimp_domains_v3.pt` trong Docker) rồi khởi động lại. Chỉ chuyển sau khi đo trên ảnh thật (xem `models/README.md`).
