# INTEGRATION SPEC: Tích hợp AI_SERVICE (đếm tôm giống) vào hệ thống nuôi tôm

| | |
|---|---|
| Gói | `AI_SERVICE_integration_v2.zip` |
| Phiên bản tài liệu | 2.0 |
| Ngày | 2026-11-03 |
| Đối tượng đọc | Lập trình viên backend và frontend của hệ thống nuôi tôm (ChillShrimp), người vận hành triển khai |
| Nguồn mã | Dự án huấn luyện `shrimp-seed-detection` (nhánh `feature/cloudinary`); `app/main.py` trong gói giống `ai_service/main.py` của dự án, chỉ khác hai chỗ: đường dẫn import (`app.cloudinary_config`) và đường dẫn model mặc định (`models/best.pt`) |
| Tài liệu gốc | `TECHSPEC.md` trong dự án huấn luyện (mô tả huấn luyện, dữ liệu, đánh giá đầy đủ) |

Quy ước: **[Đã xác minh]** là điều tôi đã đọc từ mã hoặc đã chạy khi chuẩn bị gói. **[Chưa kiểm]** là điều chưa chạy thử và cần kiểm trước khi dựa vào. **[Đề xuất]** là khuyến nghị, không phải hành vi của dịch vụ.

---

## 1. Mục đích và phạm vi

AI_SERVICE là **một dịch vụ HTTP độc lập** nhận **một ảnh mẫu tôm giống** và trả về **số con đếm được**, danh sách khung từng con, cùng đường dẫn **ảnh gốc** và **ảnh đã vẽ khung** (lưu trên Cloudinary). Hệ thống nuôi tôm chỉ cần gọi một endpoint `POST /predict`.

**Dịch vụ làm:** phát hiện tôm giống, đếm, vẽ khung, lưu hai ảnh lên Cloudinary.

**Dịch vụ không làm (phía hệ thống nuôi tôm phải làm):**
- Xác thực người dùng, phân quyền, giới hạn dung lượng upload.
- Lưu số đếm, lịch sử kiểm tra, liên kết với lô giống, ao, bể.
- Tính mật độ (con/ml), hiệu chỉnh số đếm của người dùng.
- Xử lý video (chưa hỗ trợ).
- Chuẩn hóa hướng ảnh (xem mục 15, giới hạn số 7).

---

## 2. Nội dung gói

```text
AI_SERVICE/
├── README.md                    Chạy nhanh
├── Dockerfile                   Đóng gói (CHƯA build thử, xem mục 12)
├── docker-compose.example.yml   Khối cấu hình mẫu để ghép vào compose của hệ thống
├── .env.example                 Chỉ có giá trị mẫu; KHÔNG chứa khóa thật
├── .dockerignore, .gitignore
├── requirements.txt             Thư viện (đã ghim phiên bản)
├── app/
│   ├── main.py                  FastAPI: /health, /predict
│   ├── cloudinary_config.py     Đọc biến môi trường Cloudinary
│   └── __init__.py
├── models/
│   ├── best.pt                  Model mặc định (yolov8n, đã dùng cho dịch vụ)
│   ├── candidates/
│   │   └── shrimp_domains_v3.pt Model ứng viên (yolov8s), chưa là mặc định
│   └── README.md                Mô tả model, số đo, cách chuyển model
├── examples/
│   ├── call_predict.py          Gọi từ Python
│   ├── call_predict.js          Gọi từ Node.js 18+ [Chưa kiểm]
│   ├── call_predict.ps1         Gọi bằng PowerShell/curl
│   └── response_sample.json     Phản hồi mẫu thật (URL Cloudinary là giả)
└── docs/
    └── INTEGRATION_SPEC.md      File này
```

---

## 3. Kiến trúc và luồng tích hợp

```text
┌─────────┐   ảnh   ┌───────────────┐  POST /predict   ┌─────────────────┐   upload    ┌────────────┐
│ Người   │ ──────▶ │ Backend hệ    │ ───────────────▶ │  AI_SERVICE     │ ──────────▶ │ Cloudinary │
│ dùng /  │         │ thống nuôi    │ ◀─────────────── │  (FastAPI+YOLO) │  ảnh gốc +  │            │
│ frontend│ ◀────── │ tôm           │   JSON kết quả   │  cổng 8001      │  ảnh có khung└────────────┘
└─────────┘ hiển thị└───────┬───────┘                  └─────────────────┘
                            │ lưu: số đếm, URL, tham số, phiên bản model
                            ▼
                       Cơ sở dữ liệu của hệ thống
```

**Quy tắc kiến trúc**
- **Chỉ backend gọi AI_SERVICE.** Frontend gọi backend, không gọi thẳng dịch vụ AI (dịch vụ không có xác thực).
- AI_SERVICE chạy trong **mạng nội bộ** (Docker network); không mở cổng ra internet.
- Trong Docker Compose, backend gọi bằng **tên service**: `http://ai-service:8001`, **không** dùng `localhost` (trong container backend, `localhost` là chính backend).
- AI_SERVICE **không có trạng thái**: không có database, chỉ giữ model trong bộ nhớ sau lần gọi đầu.

**Trình tự một lần kiểm tra**
1. Người dùng tải ảnh lên (frontend → backend).
2. Backend kiểm tra loại file và dung lượng, rồi gửi `POST /predict` kèm file.
3. AI_SERVICE: đọc ảnh → kiểm tra cấu hình Cloudinary → (lần đầu) nạp model → suy luận → vẽ khung → upload ảnh gốc → upload ảnh có khung → trả JSON.
4. Backend lưu kết quả và trả cho frontend; frontend hiển thị `annotated_image_url`.

---

## 4. Hợp đồng API

### 4.1. `POST /predict`

**Request:** `multipart/form-data`, field ảnh **bắt buộc đặt tên `file`**.

| Tham số (query) | Kiểu | Mặc định | Giới hạn | Ý nghĩa |
|---|---|---|---|---|
| `conf` | float | 0,25 | 0 đến 1 | Ngưỡng tin cậy; thấp hơn thì nhiều khung hơn và dễ nhận nhầm hơn |
| `imgsz` | int | 640 | 64 đến 2048 | Kích thước ảnh đưa vào mô hình |
| `max_det` | int | **300** | 1 đến 5000 | **Mức trần số khung trả về.** Vượt mức này bị cắt âm thầm (xem 4.4) |
| `tile_size` | int | 0 | 0 đến 4096 | Cạnh ô cắt (px); **0 = tắt cắt ô** |
| `tile_overlap` | float | 0,2 | 0 đến dưới 1 | Chồng lấn giữa các ô; chỉ có tác dụng khi `tile_size` lớn hơn 0 |
| `merge_iou` | float | 0,5 | trên 0 đến 1 | Ngưỡng gộp khung trùng giữa các ô; chỉ có tác dụng khi cắt ô |

Tham số `iou` (ngưỡng NMS của YOLO) **không có trong API**; Ultralytics dùng mặc định 0,7.

**Response 200** **[Đã xác minh: phản hồi thật khi chạy gói với Cloudinary giả lập; chỉ hiển thị 1 trong 4 khung; URL là minh họa]**
```json
{
  "filename": "sample.jpg",
  "image_saved": true,
  "annotated_image_saved": true,
  "annotated_image_url": "https://res.cloudinary.com/<cloud>/image/upload/<annotated-file>",
  "annotated_public_id": "shrimp-detection/annotated/<id>",
  "image_url": "https://res.cloudinary.com/<cloud>/image/upload/<original-file>",
  "public_id": "shrimp-detection/originals/<id>",
  "image": { "width": 640, "height": 640 },
  "count": 4,
  "detections": [
    { "class_id": 0, "class": "shrimp-seed", "confidence": 0.3564094603061676,
      "box": { "x1": 252.84, "y1": 348.83, "x2": 300.79, "y2": 399.47 } }
    // ... các khung còn lại; trong phản hồi thật, count bằng số phần tử của danh sách này
  ]
}
```
(Chú thích `//` chỉ để minh họa, không có trong JSON thật. Toàn bộ phản hồi mẫu nằm ở `examples/response_sample.json`.)

| Trường | Kiểu | Ghi chú |
|---|---|---|
| `filename` | string | Tên file client gửi lên |
| `image_saved`, `annotated_image_saved` | boolean | `true` khi thành công |
| `image_url`, `public_id` | string | Ảnh gốc trên Cloudinary (`shrimp-detection/originals`) |
| `annotated_image_url`, `annotated_public_id` | string | Ảnh đã vẽ khung, PNG (`shrimp-detection/annotated`) |
| `image.width`, `image.height` | int | Kích thước ảnh sau khi ép RGB (pixel) |
| `count` | int | `= len(detections)`; số con đếm được |
| `detections[].class_id`, `class` | int, string | Luôn là `0`, `"shrimp-seed"` (chỉ có một lớp) |
| `detections[].confidence` | float | Điểm tin cậy 0 đến 1, **không làm tròn**; không phải xác suất đã hiệu chỉnh |
| `detections[].box` | object | `x1, y1` góc trái trên; `x2, y2` góc phải dưới; pixel của **ảnh gốc**, làm tròn 2 chữ số |

### 4.2. `GET /health`
```json
{ "status": "ok", "model_path": "/app/models/best.pt", "model_exists": true,
  "model_loaded": false, "cloudinary_configured": true }
```
- `model_loaded` là `false` cho tới lần `/predict` đầu tiên; **lần gọi đầu chậm hơn** (nạp model).
- `model_path` cho biết model đang dùng; backend nên lưu giá trị này (hoặc tên model từ cấu hình) cùng mỗi kết quả (mục 6).
- `/` không có nội dung (404); dùng `/docs` (giao diện thử) hoặc `/health`.

### 4.3. Lỗi và cách xử lý

| Mã | Khi nào | Nội dung | Backend nên làm |
|---|---|---|---|
| 400 | File không phải ảnh hợp lệ | `Uploaded file is not a valid image.` | Báo người dùng chọn ảnh khác; **không thử lại** |
| 422 | Thiếu `file` hoặc tham số ngoài giới hạn | Do FastAPI sinh | Sửa lỗi lập trình/cấu hình; không thử lại |
| 503 | Chưa cấu hình đủ ba biến `CLOUDINARY_*` | `detail.message`, `detail.image_saved=false` | Báo vận hành; không thử lại tự động |
| 503 | Không thấy file model | Chuỗi hướng dẫn đặt `MODEL_PATH` | Báo vận hành; không thử lại |
| 502 | Upload ảnh gốc thất bại | `detail.image_saved=false` | Có thể thử lại tối đa 1 đến 2 lần có giãn cách; **số đếm đã tính bị bỏ, không được trả** |
| 502 | Ảnh gốc đã lưu nhưng upload ảnh có khung thất bại | `detail.image_saved=true`, kèm `image_url`, `public_id`, `annotated_image_saved=false` | Thử lại sẽ **tạo thêm bản sao ảnh gốc** trên Cloudinary (trùng); `count` không có trong lỗi này nên cần gọi lại để lấy số đếm |
| mạng | Timeout, kết nối đứt | | Thử lại tối đa 1 lần |

### 4.4. Hai điều dễ sai
- **`max_det` mặc định là 300.** Ảnh có nhiều hơn 300 con sẽ bị cắt ở 300 và đếm thiếu mà **không có cảnh báo**. Khi `count` bằng đúng `max_det` thì gần như chắc chắn đã bị cắt. **[Đề xuất]** Backend luôn truyền `max_det=1000` (ảnh dày nhất đã gặp khoảng 330 con).
- **Cắt ô không phải lúc nào cũng tốt.** Với model ứng viên `shrimp_domains_v3`, cắt ô làm đếm dư. Cấu hình tốt nhất đã đo cho v3 là **toàn ảnh** (`tile_size=0`, `conf=0.25`, `imgsz=640`).

---

## 5. Tham số theo loại ảnh **[Đề xuất, dựa trên số đo trong dự án huấn luyện]**

| Loại ảnh | Mô tả | Cấu hình khuyến nghị |
|---|---|---|
| Thưa (không quá khoảng 30 con) | Tôm thưa, ảnh cận cảnh | `conf=0.25&imgsz=640&max_det=1000` (cả hai model) |
| Dày (hàng trăm con, chồng dính) | Chậu hoặc khay đầy | Dùng model `shrimp_domains_v3` với cấu hình trên; cần kiểm chứng bằng số đếm tay (xem mục 8) |

Gợi ý đặt **một hằng số cấu hình** ở backend:
```json
{ "AI_DEFAULT_PARAMS": { "conf": 0.25, "imgsz": 640, "max_det": 1000, "tile_size": 0 } }
```
Không cần ước lượng trước số tôm: `max_det` chỉ là mức trần, đặt cao không làm tăng số khung nếu ảnh ít tôm.

---

## 6. Ánh xạ sang giao diện và dữ liệu của hệ thống nuôi tôm

Dựa trên màn hình "Kiểm tra chất lượng" của ChillShrimp **[Suy ra]**:

| Trường trên giao diện | Lấy từ đâu |
|---|---|
| Ảnh gốc | `image_url` |
| Ảnh đã đánh dấu kết quả AI | `annotated_image_url` |
| Số lượng AI đếm | `count` |
| Số đếm hiệu chỉnh | Người dùng nhập, lưu riêng với số AI |
| Thể tích mẫu (ml) | Người dùng nhập |
| Mật độ mẫu (con/ml) | **Backend tính**: `count ÷ thể tích mẫu` (hoặc số hiệu chỉnh nếu có). Giả định cả mẫu nằm trong ảnh |
| Độ tin cậy | **Backend tính**: trung bình `confidence` của các khung |
| Phiên bản model | **Backend lưu** từ cấu hình hoặc `/health.model_path`; **API không trả trường này trong `/predict`** |
| Lịch sử kiểm tra | Các bản ghi trong database của hệ thống |

**Về "độ tin cậy":** đó là điểm trung bình mà mô hình tự gán, thường chỉ khoảng 0,3 ở ngưỡng `conf=0.25`. Đây **không phải** phần trăm số đếm đúng. **[Đề xuất]** Đổi nhãn hiển thị thành "Điểm tin cậy trung bình của mô hình" hoặc không hiển thị dưới dạng %.

**Lược đồ lưu trữ gợi ý** (PostgreSQL, điều chỉnh theo hệ thống) **[Đề xuất]**:
```sql
CREATE TABLE ai_quality_checks (
  id                    BIGSERIAL PRIMARY KEY,
  batch_id              BIGINT,            -- lô giống
  tank_id               BIGINT,            -- ao hoặc bể
  image_url             TEXT NOT NULL,
  image_public_id       TEXT NOT NULL,
  annotated_image_url   TEXT,
  annotated_public_id   TEXT,
  ai_count              INTEGER NOT NULL,
  adjusted_count        INTEGER,           -- người dùng hiệu chỉnh
  sample_volume_ml      NUMERIC(10,2),
  density_per_ml        NUMERIC(12,3),
  mean_confidence       REAL,
  model_version         TEXT NOT NULL,     -- ví dụ 'yolov8n-best' hoặc 'shrimp_domains_v3'
  params                JSONB,             -- conf, imgsz, max_det, tile_size
  truncated_suspected   BOOLEAN,           -- ai_count = max_det
  created_by            BIGINT,
  created_at            TIMESTAMPTZ DEFAULT now()
);
```
Danh sách `detections` có thể rất dài (hàng trăm khung): chỉ lưu khi thực sự cần vẽ lại; ảnh `annotated_image_url` đã đủ để xem lại.

---

## 7. Tiêu chí ảnh đầu vào **[Đề xuất, rút từ TECHSPEC mục 2]**

Để số đếm đáng tin, hướng dẫn người dùng chụp:
- **Nền sáng, phẳng** (khay hoặc chậu trắng), chụp **từ trên xuống**, đủ sáng, tránh phản chiếu và bóng.
- **Toàn bộ mẫu nằm trong khung hình**; không để tay, thước, đồng xu hoặc vật khác che tôm.
- **Độ phân giải đủ:** cạnh dài từ khoảng 600 px trở lên; thấy rõ đầu và mắt từng con khi phóng to. Không dùng ảnh nén nặng, ảnh có chữ chìm hay logo đè lên tôm.
- **Không để tôm chồng dính quá nhiều:** con bị che kín không thể đếm. Với mẫu rất dày, cân nhắc chia mẫu thành nhiều ảnh nhỏ hơn rồi cộng số đếm (cách này chưa được kiểm chứng).

**Các kiểu ảnh mô hình đã được học** (mô hình chỉ biết các kiểu này; kiểu khác có thể đếm sai):

| Loại | Đặc điểm | Mức độ kiểm chứng |
|---|---|---|
| A | Tôm nhỏ, thân tối, rất dày (hàng trăm con) | Đo trên 5 ảnh test (4 ảnh dễ, 1 ảnh chậu thật) |
| B | Tôm to hơn, thân trong suốt, đốm cam, thưa | **Chưa đo được** (không có ảnh test) |
| C | Ảnh cận cảnh 640×640, tôm nhỏ, thưa | Đo trên 10 ảnh test |

Khung được vẽ quanh **vùng đầu và thân sẫm** của con tôm, không bao râu và đuôi mảnh.

---

## 8. Mô hình và chất lượng **[Đã xác minh, do tôi chạy khi chuẩn bị]**

| Model | File | Kiến trúc | Vai trò |
|---|---|---|---|
| Mặc định | `models/best.pt` | YOLOv8n (khoảng 3 triệu tham số, 6 MB) | Model dịch vụ đã dùng; huấn luyện trên 210 ảnh gốc |
| Ứng viên | `models/candidates/shrimp_domains_v3.pt` | YOLOv8s (khoảng 11 triệu tham số, 22 MB) | Huấn luyện trên dữ liệu 3 loại A, B, C; chưa là mặc định |

**Sai số đếm theo loại ảnh** (toàn ảnh, `conf=0.25`; sai số tương đối trung bình trên ảnh test giữ riêng):

| Loại | Model mặc định | Ứng viên v3 |
|---|---:|---:|
| A (5 ảnh test) | 28% | 12% |
| C (10 ảnh test) | 19% (từng học các ảnh này) | 11% |
| B | không đo được | không đo được |

**Cách đọc:** tập test **nhỏ** (5 và 10 ảnh); ảnh chậu dày thật chỉ có 1 ảnh test và số thật của nó có dấu hiệu chưa đầy đủ; kết quả trên ảnh dày thay đổi nhiều giữa các lần huấn luyện. Vì vậy **v3 là ứng viên tốt nhất, chưa phải bản đã được chứng minh**. Chi tiết trong dự án huấn luyện: `TECHSPEC.md` mục 13.

**Cách chuyển model** (không cần build lại code):
1. Đặt `MODEL_PATH=/app/models/candidates/shrimp_domains_v3.pt` trong biến môi trường của container.
2. **Khởi động lại dịch vụ** (model chỉ được nạp một lần khi gọi đầu tiên).
3. Gọi `GET /health` kiểm tra `model_path`, rồi chạy bộ kiểm tra nghiệm thu (mục 14) trên ảnh thật.
4. Cập nhật `model_version` mà backend lưu.

**Quy tắc thay model mặc định** **[Đề xuất]:** chỉ thay khi trên ảnh thật của hệ thống có số đếm tay, sai số mỗi loại nằm trong ngưỡng bạn chấp nhận, không loại nào lùi quá 5 điểm phần trăm so với model hiện tại, và thời gian xử lý chấp nhận được.

---

## 9. Hiệu năng và tài nguyên

**Thời gian suy luận đo trên CPU** (Intel i5-11400H, 6 luồng; **chỉ phần chạy mô hình**, chưa gồm giải mã ảnh và hai lần upload Cloudinary):

| Model | Ảnh 600×337, toàn ảnh | Ảnh 1200×800, toàn ảnh | Ảnh 600×337, cắt ô 320 | Ảnh 1200×800, cắt ô 320 |
|---|---:|---:|---:|---:|
| YOLOv8n (mặc định) | khoảng 40 ms | khoảng 48 ms | khoảng 0,37 s | khoảng 0,9 s |
| YOLOv8s (v3) | khoảng 84 ms | khoảng 104 ms | khoảng 1,0 s | khoảng 2,1 s |

- Thời gian **hai lần upload Cloudinary phụ thuộc mạng, chưa đo**; thường là phần lớn tổng thời gian.
- **Lần gọi đầu chậm hơn** do nạp model. **[Đề xuất]** Gọi `/predict` một ảnh mẫu khi khởi động (làm nóng).
- **Timeout khuyến nghị cho backend:** 60 giây cho toàn ảnh, 120 giây nếu dùng cắt ô.
- **Bộ nhớ:** chưa đo trong container. Ảnh rất lớn kết hợp cắt ô có thể tốn nhiều RAM; dịch vụ không giới hạn kích thước ảnh, backend nên giới hạn (ví dụ 10 MB và 4000 px mỗi cạnh).
- **Đồng thời:** dịch vụ chạy suy luận trực tiếp trong tiến trình; **một yêu cầu suy luận chặn các yêu cầu khác trong lúc chạy**. Nếu có nhiều người dùng cùng lúc, chạy nhiều bản sao (replica) hoặc đặt hàng đợi ở backend. `uvicorn --workers N` nạp N bản model vào bộ nhớ.

---

## 10. Cấu hình

| Biến | Bắt buộc | Mô tả |
|---|---|---|
| `CLOUDINARY_CLOUD_NAME` | Có | Tên cloud |
| `CLOUDINARY_API_KEY` | Có | API key |
| `CLOUDINARY_API_SECRET` | Có | API secret |
| `MODEL_PATH` | Không | Đường dẫn model; mặc định `models/best.pt` (Docker: `/app/models/best.pt`) |

- Thiếu **cả ba** biến Cloudinary: dịch vụ vẫn khởi động, `/health` báo `cloudinary_configured: false`, `/predict` trả 503.
- Có **một hoặc hai** biến: dịch vụ **báo lỗi ngay khi khởi động** (tránh chạy với cấu hình thiếu).
- Backend cần các biến sau (tên gợi ý): `AI_SERVICE_URL`, `AI_TIMEOUT_SECONDS`, `AI_MAX_UPLOAD_MB`.

---

## 11. Bảo mật

- Dịch vụ **không có xác thực, không giới hạn tốc độ, không giới hạn upload, không bật CORS**. Mọi ai truy cập được cổng 8001 đều có thể tải ảnh lên tài khoản Cloudinary của bạn.
  - Chỉ cho truy cập từ backend trong mạng nội bộ; **không publish cổng 8001** ra ngoài.
  - **[Đề xuất]** Nếu cần, đặt thêm khóa API ở lớp trung gian (reverse proxy) hoặc mạng riêng.
- **Credentials Cloudinary:** truyền bằng biến môi trường hoặc secret manager; **không** đưa vào image, repo hay file `.env.example`. **Lưu ý:** trong lịch sử repo huấn luyện từng có `.env.example` chứa giá trị trông như khóa thật; nếu bạn từng dùng khóa đó, **hãy đổi (rotate) secret** và dùng khóa mới.
- Container chạy bằng **người dùng không phải root** (xem `Dockerfile`).
- Backend nên kiểm tra **loại file và dung lượng** trước khi chuyển tiếp, và không ghi tên file người dùng vào đường dẫn hệ thống.
- Ảnh có thể chứa thông tin riêng tư; lưu ý quyền truy cập thư mục `shrimp-detection/` trên Cloudinary (mặc định URL công khai nếu biết đường dẫn).

---

## 12. Triển khai

### 12.1. Docker Compose
Ghép khối trong `docker-compose.example.yml` vào compose của hệ thống; backend gọi `http://ai-service:8001`. Dùng `expose` thay cho `ports` để giữ cổng nội bộ.

### 12.2. Dockerfile **[Chưa kiểm]**
`Dockerfile` trong gói **chưa được build** (lúc chuẩn bị gói, máy không có Docker daemon chạy). Có các điểm cần kiểm tra khi build lần đầu:
- Cài `libgl1`, `libglib2.0-0` (thư viện cần cho OpenCV trên image slim).
- Cài **PyTorch bản CPU** trước để image nhỏ hơn; cần kiểm tra tương thích với `ultralytics==8.3.184`.
- Chạy bằng người dùng `appuser`; kiểm tra quyền ghi thư mục cấu hình của Ultralytics.
- `HEALTHCHECK` dùng `GET /health`, `start-period` 60 giây để có thời gian khởi động.

Nếu image quá lớn hoặc build lỗi, dùng cách chạy trực tiếp bằng Python (README.md của gói).

### 12.3. Chạy trực tiếp (không Docker)
```powershell
python -m venv .venv ; .\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env      # rồi điền 3 biến Cloudinary
uvicorn app.main:app --host 0.0.0.0 --port 8001
```
Mở `http://localhost:8001/docs` (không mở `0.0.0.0`; đó chỉ là địa chỉ để server lắng nghe).

---

## 13. Vận hành

- **Giám sát:** gọi `GET /health` định kỳ (`status`, `model_exists`, `cloudinary_configured`).
- **Nhật ký:** uvicorn ghi log truy cập; dịch vụ không ghi số đếm hay thời gian xử lý. **[Đề xuất]** Backend ghi mỗi lần gọi: thời gian, `count`, tham số, `model_version`, mã lỗi.
- **Cập nhật model:** thay file model hoặc đổi `MODEL_PATH` rồi khởi động lại (mục 8). Giữ model cũ để **quay lại** khi cần; không ghi đè `best.pt` khi chưa đo.
- **Dọn dẹp Cloudinary:** mỗi lần gọi thành công tạo 2 ảnh; lỗi 502 ở giữa có thể để lại ảnh gốc mồ côi. Cân nhắc quy định lưu giữ.

---

## 14. Kiểm tra nghiệm thu (checklist)

1. `GET /health` trả `status: ok`, `model_exists: true`, `cloudinary_configured: true`.
2. Gọi `POST /predict` bằng một ảnh thưa và một ảnh dày thật; nhận `200`, `count` hợp lý.
3. Mở `annotated_image_url`: số khung vẽ khớp `count`, khung nằm trên đầu tôm, không có khung bắt vật khác (chấm đen, thước, đồng xu).
4. Kiểm tra trên Cloudinary có đủ 2 ảnh (`originals` và `annotated`).
5. Đếm tay **ít nhất 5 ảnh thật** của hệ thống, tính sai số theo loại, so với ngưỡng bạn chấp nhận.
6. Ảnh không phải ảnh (file `.txt`) trả `400`.
7. Tắt biến Cloudinary: `/predict` trả `503`, `/health` báo `cloudinary_configured: false`.
8. Ảnh có hơn `max_det` con (thử `max_det=50` trên ảnh dày): xác nhận `count` dừng đúng ở 50, để biết hiện tượng cắt.
9. Đo thời gian xử lý đầu cuối (gồm upload) trên môi trường thật; đặt timeout phù hợp.
10. Chạy 5 đến 10 yêu cầu liên tiếp; xác nhận không lỗi bộ nhớ.
11. Trong Docker Compose: backend gọi được `http://ai-service:8001/health`; từ ngoài **không** truy cập được cổng 8001.
12. Hiển thị trên giao diện: ảnh gốc, ảnh có khung, số đếm, số hiệu chỉnh, mật độ.

Lệnh mẫu:
```powershell
curl.exe -s http://localhost:8001/health
curl.exe -s -X POST "http://localhost:8001/predict?conf=0.25&imgsz=640&max_det=1000" -F "file=@anh.jpg"
```

---

## 15. Giới hạn đã biết

1. **Độ chính xác chưa được chứng minh rộng:** tập test nhỏ (5 ảnh loại A, 10 ảnh loại C), loại B chưa đo được; kết quả trên ảnh dày thay đổi giữa các lần huấn luyện.
2. **Đếm bị cắt âm thầm** khi số khung chạm `max_det` (mặc định 300); API chưa có cờ báo cắt.
3. **Chưa có tham số `iou`:** khung đôi trên ảnh dày có thể xuất hiện; chưa chỉnh được qua API.
4. **Cloudinary là điều kiện bắt buộc:** Cloudinary lỗi thì `/predict` trả 502 và **không trả số đếm**, dù mô hình đã chạy xong.
5. **Một yêu cầu suy luận chặn các yêu cầu khác** trong tiến trình (xem mục 9).
6. **Ảnh rất dày, tôm chồng dính:** con bị che kín không đếm được; số đếm là ước lượng.
7. **Hướng ảnh (EXIF):** mã đọc ảnh bằng Pillow và không áp dụng cờ xoay EXIF **[suy từ mã, chưa kiểm bằng ảnh thật]**. Ảnh chụp điện thoại có thể mang cờ xoay; khi đó mô hình đọc ảnh chưa xoay và ảnh có khung có thể hiển thị khác hướng với ảnh gốc. **[Đề xuất]** Chuẩn hóa hướng ảnh ở frontend hoặc backend trước khi gửi.
8. **Không có thông tin phiên bản model trong phản hồi** `/predict`; backend phải tự lưu.
9. **Dockerfile chưa build thử**; ví dụ Node.js chưa chạy thử.
10. **Xử lý video chưa hỗ trợ.** Hướng làm: lấy mẫu khung hình rồi lấy trung vị số đếm.

---

## 16. Thay đổi so với `AI_SERVICE_integration.zip` (bản cũ)

| Mục | Bản cũ | Bản này |
|---|---|---|
| Tham số `/predict` | `conf`, `imgsz` | Thêm `max_det`, `tile_size`, `tile_overlap`, `merge_iou` |
| Ảnh có khung | Không | Có, lưu `shrimp-detection/annotated`, trả `annotated_image_url` và `annotated_public_id` |
| Cắt ô để đếm ảnh dày | Không | Có (mặc định tắt) |
| Model | `best.pt` (YOLOv8n) | `best.pt` (YOLOv8n) cộng ứng viên `shrimp_domains_v3.pt` (YOLOv8s) |
| Dockerfile | Cơ bản | Thêm thư viện hệ thống, PyTorch CPU, người dùng không phải root, healthcheck (chưa build thử) |
| Tài liệu | README | README, `INTEGRATION_SPEC.md`, `models/README.md`, ví dụ gọi API |
| Đường dẫn zip | Dấu `\` | Dấu `/` chuẩn |

---

## 17. Phụ lục

### 17.1. Thuật ngữ
| Thuật ngữ | Giải thích |
|---|---|
| Khung (bounding box) | Hình chữ nhật bao quanh một con tôm |
| Confidence | Điểm tin cậy mô hình gán cho một khung, từ 0 đến 1 |
| NMS | Bỏ các khung chồng lấn, giữ khung điểm cao nhất |
| IoU | Mức trùng nhau giữa hai khung |
| Cắt ô (tiling) | Cắt ảnh thành các ô nhỏ chồng lấn rồi gộp kết quả |
| `max_det` | Mức trần số khung trả về |
| Sai số tương đối | `abs(đếm − thật) ÷ thật` |

### 17.2. Ví dụ gọi từ Python
```python
import requests
with open("anh.jpg", "rb") as f:
    r = requests.post("http://ai-service:8001/predict",
                      params={"conf": 0.25, "imgsz": 640, "max_det": 1000},
                      files={"file": ("anh.jpg", f)}, timeout=120)
r.raise_for_status()
data = r.json()
count = data["count"]
mean_conf = sum(d["confidence"] for d in data["detections"]) / max(1, count)
```
Các ví dụ đầy đủ hơn (xử lý lỗi, Node.js, PowerShell) nằm trong thư mục `examples/`.
