# PowerShell. Usage: .\call_predict.ps1 -Image path\to\image.jpg
param([Parameter(Mandatory = $true)][string]$Image,
      [string]$BaseUrl = "http://localhost:8001")

curl.exe -s -X POST "$BaseUrl/predict?conf=0.25&imgsz=640&max_det=1000" -F "file=@$Image"
