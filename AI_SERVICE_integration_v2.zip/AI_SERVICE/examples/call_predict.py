"""Call the AI service from Python.  pip install requests

Usage: python call_predict.py path/to/image.jpg [conf] [max_det]
"""
import os
import sys

import requests

BASE_URL = os.getenv("AI_SERVICE_URL", "http://localhost:8001")


def predict(image_path, conf=0.25, max_det=1000, timeout=120):
    params = {"conf": conf, "imgsz": 640, "max_det": max_det}
    with open(image_path, "rb") as handle:
        response = requests.post(f"{BASE_URL}/predict", params=params, timeout=timeout,
                                 files={"file": (os.path.basename(image_path), handle)})
    response.raise_for_status()
    return response.json()


if __name__ == "__main__":
    result = predict(sys.argv[1],
                     conf=float(sys.argv[2]) if len(sys.argv) > 2 else 0.25,
                     max_det=int(sys.argv[3]) if len(sys.argv) > 3 else 1000)
    scores = [d["confidence"] for d in result["detections"]]
    print("count:", result["count"])
    print("mean confidence:", round(sum(scores) / len(scores), 3) if scores else None)
    print("original:", result["image_url"])
    print("annotated:", result["annotated_image_url"])
