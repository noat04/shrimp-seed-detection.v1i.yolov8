// Node.js 18+ (built-in fetch, FormData, Blob). NOT run during preparation: verify before use.
// Usage: node call_predict.js path/to/image.jpg
import { readFile } from "node:fs/promises";
import path from "node:path";

const BASE_URL = process.env.AI_SERVICE_URL ?? "http://localhost:8001";

export async function predict(imagePath, { conf = 0.25, maxDet = 1000 } = {}) {
  const form = new FormData();
  form.append("file", new Blob([await readFile(imagePath)]), path.basename(imagePath));
  const query = new URLSearchParams({ conf, imgsz: 640, max_det: maxDet });
  const response = await fetch(`${BASE_URL}/predict?${query}`, {
    method: "POST",
    body: form,
    signal: AbortSignal.timeout(120_000),
  });
  if (!response.ok) {
    throw new Error(`AI service ${response.status}: ${await response.text()}`);
  }
  return response.json();
}

const result = await predict(process.argv[2]);
console.log("count:", result.count);
console.log("annotated:", result.annotated_image_url);
