# Các model trong gói

| File | Kiến trúc | Kích thước | Vai trò |
|---|---|---|---|
| `best.pt` | YOLOv8n | khoảng 6 MB | **Mặc định.** Huấn luyện 30 epoch trên 210 ảnh gốc (1 lớp: `shrimp-seed`) |
| `candidates/shrimp_domains_v3.pt` | YOLOv8s | khoảng 22 MB | **Ứng viên.** Huấn luyện 60 epoch trên dữ liệu chia 3 loại ảnh (A, B, C) có cân bằng |

Cả hai model có một lớp duy nhất `shrimp-seed`. Khung được vẽ quanh **vùng đầu và thân sẫm** của con tôm.

## Số đo (sai số đếm tương đối trên ảnh test giữ riêng, toàn ảnh, `conf=0.25`)

| Loại ảnh | `best.pt` | `shrimp_domains_v3.pt` |
|---|---:|---:|
| A: tôm nhỏ, thân tối, rất dày (5 ảnh test) | 28% | 12% |
| C: ảnh cận cảnh 640×640, thưa (10 ảnh test) | 19% (từng học các ảnh này) | 11% |
| B: tôm to, thân trong suốt, thưa | không đo được | không đo được |

Chỉ số phát hiện trên tập valid của v3 (epoch 31): Precision 90,2%, Recall 90,6%, mAP50 94,9%, mAP50–95 41,6%.

## Cách đọc số đo

- Tập test **nhỏ**; loại B chưa có ảnh test; số thật của ảnh chậu dày duy nhất trong tập test có dấu hiệu chưa đầy đủ; kết quả trên ảnh dày thay đổi giữa các lần huấn luyện. **v3 là ứng viên tốt nhất đã thử, chưa phải bản đã được chứng minh.**
- Cấu hình tốt nhất đã đo cho v3: **toàn ảnh** (`tile_size=0`), `conf=0.25`, `imgsz=640`. Cắt ô làm v3 đếm dư.
- Thời gian suy luận trên CPU (i5-11400H): `best.pt` khoảng 40 đến 50 ms, `shrimp_domains_v3.pt` khoảng 85 đến 105 ms cho một ảnh toàn ảnh (chưa gồm upload Cloudinary).

## Chuyển sang model ứng viên

1. Đặt `MODEL_PATH` (Docker: `/app/models/candidates/shrimp_domains_v3.pt`).
2. Khởi động lại dịch vụ (model chỉ được nạp một lần).
3. Gọi `GET /health` kiểm tra `model_path`.
4. Chạy kiểm tra nghiệm thu trên ảnh thật (xem `docs/INTEGRATION_SPEC.md` mục 14) trước khi chuyển hẳn.
5. Giữ `best.pt` để quay lại khi cần.
