# AI_SERVICE — Shrimp Seed Detection

AI inference service extracted from the shrimp-seed training project. It exposes a FastAPI endpoint using the included YOLOv8 model and uploads original images to Cloudinary after successful inference.

## Contents

- `app/`: FastAPI service and Cloudinary configuration.
- `models/best.pt`: trained YOLOv8n model.
- `requirements.txt`: service dependencies.
- `.env.example`: placeholder environment variables only; no credentials are included.
- `Dockerfile`: container build definition.

## Run locally (PowerShell)

From this directory:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env
uvicorn app.main:app --host 0.0.0.0 --port 8001
```

Fill the three Cloudinary values in `.env`. Open `http://localhost:8001/docs` to try `POST /predict`, or `http://localhost:8001/health` to inspect service status. The API requires Cloudinary configuration for a successful `/predict` response.

## API

`POST /predict` accepts multipart form field `file` and optional query parameters `conf` (default `0.25`) and `imgsz` (default `640`). It returns the shrimp count, detection class/confidence/boxes, and Cloudinary `image_url`/`public_id`.

`GET /health` reports service, model-file, model-load and Cloudinary configuration status.

## Docker

Build from this directory:

```powershell
docker build -t shrimp-ai-service .
```

Provide `CLOUDINARY_CLOUD_NAME`, `CLOUDINARY_API_KEY`, and `CLOUDINARY_API_SECRET` through Docker Compose or deployment secrets. Do not put real credentials in the image or Git.

## Integration notes

In the main project's `docker-compose.yml`, build this directory as its own service and pass Cloudinary credentials via environment/secrets. Configure the backend to call `http://AI_SERVICE:8001/predict` on the Compose network (use the actual Compose service name). The frontend should call the backend, not the internal AI service directly.
